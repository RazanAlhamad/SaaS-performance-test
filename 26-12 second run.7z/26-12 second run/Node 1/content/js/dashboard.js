/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.53108618301329, "KoPercent": 8.468913816986719};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21810576635793247, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.21688247011952191, 500, 1500, "GetCmsPage"], "isController": false}, {"data": [0.09692570452604611, 500, 1500, "addSimpleProductToCart"], "isController": false}, {"data": [0.10465116279069768, 500, 1500, "Catalog__ProductSearch(Sort descending)"], "isController": false}, {"data": [0.10869565217391304, 500, 1500, "Catalog__ProductSearch(Filtring)"], "isController": false}, {"data": [0.0, 500, 1500, "Catalog__ProductSearch(RemoveFilter)"], "isController": false}, {"data": [0.19754977029096477, 500, 1500, "checkUserIsAuthed"], "isController": false}, {"data": [0.20572002007024587, 500, 1500, "getAvailableStoresData"], "isController": false}, {"data": [0.1915269196822595, 500, 1500, "productReviewRatingsMetadata"], "isController": false}, {"data": [0.024390243902439025, 500, 1500, "Catalog__ProductSearch(SortBasedon value from drop down list)"], "isController": false}, {"data": [0.16224783861671468, 500, 1500, "Catalog__GetBreadcrumbs"], "isController": false}, {"data": [0.13228941684665227, 500, 1500, "createProductReview"], "isController": false}, {"data": [0.11038961038961038, 500, 1500, "updateItemQuantity"], "isController": false}, {"data": [0.17037216046399226, 500, 1500, "launch_getStoreConfig"], "isController": false}, {"data": [0.16056137012369173, 500, 1500, "GetCartDetails"], "isController": false}, {"data": [0.9997609942638623, 500, 1500, "JSR223 Sampler - Instead of Cache"], "isController": false}, {"data": [0.10427807486631016, 500, 1500, "Search_getAutocompleteResults(after adding space after the input)"], "isController": false}, {"data": [0.10139453805926786, 500, 1500, "ProductSearch"], "isController": false}, {"data": [0.1721311475409836, 500, 1500, "GetAttributeProduct"], "isController": false}, {"data": [0.17966016991504247, 500, 1500, "getLandingPage"], "isController": false}, {"data": [0.18879353861686018, 500, 1500, "getWebTranslations"], "isController": false}, {"data": [0.06311154598825831, 500, 1500, "getMegaMenu"], "isController": false}, {"data": [0.2171867261020307, 500, 1500, "CmsBlockList"], "isController": false}, {"data": [0.21122599704579026, 500, 1500, "launch_getAllWebsites"], "isController": false}, {"data": [0.1538871139510117, 500, 1500, "AttributeProduct"], "isController": false}, {"data": [0.16263440860215053, 500, 1500, "amMostviewedGroups"], "isController": false}, {"data": [0.16843501326259946, 500, 1500, "productReviews"], "isController": false}, {"data": [0.20855614973262032, 500, 1500, "launch_ResolveURL"], "isController": false}, {"data": [0.18331643002028397, 500, 1500, "launch_createEmptyCart"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 36817, 3118, 8.468913816986719, 4259.266507320031, 0, 34956, 2369.0, 3236.9000000000015, 4932.150000000012, 32781.98, 22.610698274273783, 43.717554471112514, 52.23855857143954], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetCmsPage", 2008, 147, 7.320717131474104, 4339.4965139442165, 211, 33086, 2215.5, 7613.700000000008, 30160.0, 32691.28, 1.2645887441525365, 2.087706868384211, 1.2213654960613856], "isController": false}, {"data": ["addSimpleProductToCart", 1171, 66, 5.636208368915457, 4494.382578992308, 289, 33317, 2804.0, 7131.0, 30157.0, 32579.719999999998, 0.7717712314529401, 1.3214924365101177, 4.884581176731987], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 43, 7, 16.27906976744186, 4973.86046511628, 233, 32786, 2560.0, 9657.600000000002, 32254.59999999999, 32786.0, 0.03455522205748221, 0.2383181815213941, 0.10589285821912028], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 46, 2, 4.3478260869565215, 5427.195652173913, 324, 32415, 4444.0, 9185.900000000012, 24667.099999999977, 32415.0, 0.03119722751595467, 0.30776398746346195, 0.1088551698383848], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 40, 11, 27.5, 7153.525, 287, 32920, 4199.0, 29716.699999999993, 32237.49999999999, 32920.0, 0.028831571724300977, 0.155252664127326, 0.09491119718236257], "isController": false}, {"data": ["checkUserIsAuthed", 1959, 138, 7.044410413476263, 4370.451250638069, 223, 33070, 2262.0, 7636.0, 30163.0, 32674.0, 1.2298462786320643, 1.2831823121941863, 1.0662909028650585], "isController": false}, {"data": ["getAvailableStoresData", 1993, 159, 7.977922729553437, 4600.765178123442, 218, 33052, 2229.0, 8292.600000000002, 30189.3, 32635.899999999998, 1.252074750056227, 1.490801439155638, 1.1860473706587307], "isController": false}, {"data": ["productReviewRatingsMetadata", 1133, 87, 7.678729037952339, 4540.824360105914, 213, 33110, 2240.0, 7942.800000000003, 30186.9, 32722.260000000002, 0.722928312692975, 0.8334744222635121, 0.648468426241532], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 41, 7, 17.073170731707318, 6017.1463414634145, 295, 30553, 4475.0, 9447.000000000016, 30287.6, 30553.0, 0.03826390146205434, 0.26075029707019837, 0.11807909702558828], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1735, 341, 19.654178674351584, 4374.946397694531, 203, 33080, 2194.0, 7858.600000000008, 30166.0, 32648.399999999998, 1.104713465342878, 1.1679945994394934, 1.0864139126563235], "isController": false}, {"data": ["createProductReview", 926, 48, 5.183585313174946, 4127.552915766735, 220, 33233, 2616.0, 6219.0, 30152.3, 32564.92, 0.6186138640318793, 0.7791271160468837, 0.8555626814172003], "isController": false}, {"data": ["updateItemQuantity", 77, 6, 7.792207792207792, 5571.883116883116, 277, 33000, 3080.0, 12843.400000000025, 30294.9, 33000.0, 0.054094306749845444, 0.09280513338286124, 0.34122127227877536], "isController": false}, {"data": ["launch_getStoreConfig", 2069, 137, 6.621556307394877, 4515.722571290472, 392, 33207, 2428.0, 7967.0, 30300.0, 32673.30000000001, 1.2769547622265796, 3.787791557965044, 9.49111591338525], "isController": false}, {"data": ["GetCartDetails", 2102, 143, 6.803044719314938, 4485.653663177934, 265, 34956, 2475.0, 7147.600000000004, 30163.85, 32686.64, 1.3153144020669585, 1.6091288234146612, 5.2495481246601425], "isController": false}, {"data": ["JSR223 Sampler - Instead of Cache", 2092, 0, 0.0, 0.6448374760994255, 0, 769, 0.0, 1.0, 1.0, 1.0, 1.3369103567096667, 0.0, 0.0], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 187, 10, 5.347593582887701, 4588.406417112299, 207, 33293, 2781.0, 6518.600000000017, 30160.0, 32552.920000000006, 0.12923932635210597, 0.23064219936997554, 0.18595228671537214], "isController": false}, {"data": ["ProductSearch", 1721, 334, 19.407321324811157, 5213.460197559571, 203, 34416, 2647.0, 9179.399999999998, 30160.0, 32701.42, 1.0871171875690897, 7.202153218263253, 3.1647826124891507], "isController": false}, {"data": ["GetAttributeProduct", 183, 8, 4.371584699453552, 3698.5464480874325, 234, 34707, 2247.0, 6751.999999999998, 10339.799999999994, 33371.399999999994, 0.13204130078719706, 0.1444180588575902, 0.12225545301710763], "isController": false}, {"data": ["getLandingPage", 2001, 127, 6.346826586706647, 4331.788105947028, 275, 33141, 2431.0, 7019.4, 30162.0, 32749.94, 1.2405163424544245, 5.296812574122557, 13.178063255096903], "isController": false}, {"data": ["getWebTranslations", 1981, 267, 13.47804139323574, 4421.281675921249, 205, 33071, 2226.0, 7388.4, 30168.7, 32694.08, 1.23439788987127, 1.2352473757361369, 1.1488815596081456], "isController": false}, {"data": ["getMegaMenu", 2044, 278, 13.600782778864971, 5438.113992172215, 210, 33156, 3033.0, 9590.0, 30165.5, 32657.1, 1.2590028869601424, 3.8765135444442183, 1.737827431603313], "isController": false}, {"data": ["CmsBlockList", 2019, 139, 6.884596334819218, 4262.68202080237, 214, 33184, 2202.0, 7312.0, 30159.0, 32582.4, 1.2499651755616021, 4.078317791960353, 1.1114570177434384], "isController": false}, {"data": ["launch_getAllWebsites", 2031, 138, 6.794682422451994, 4386.036927621863, 211, 32992, 2213.0, 7966.999999999999, 30157.0, 32583.8, 1.2660018961978179, 2.2137179141995422, 1.5093580208248274], "isController": false}, {"data": ["AttributeProduct", 939, 61, 6.496272630457934, 4235.604898828541, 253, 32938, 2501.0, 6778.0, 30154.0, 32640.6, 0.6177391798607818, 0.6709160836849096, 0.5767630514259644], "isController": false}, {"data": ["amMostviewedGroups", 1116, 83, 7.437275985663082, 4352.956093189967, 233, 32922, 2254.0, 7253.900000000001, 30164.15, 32424.049999999996, 0.7303894363173713, 0.8187909320368049, 1.3461748962009277], "isController": false}, {"data": ["productReviews", 1131, 82, 7.250221043324491, 4317.0026525198955, 210, 33033, 2364.0, 6914.200000000001, 30155.4, 32608.640000000003, 0.7274210063236104, 0.8092130336591399, 0.8494347905416617], "isController": false}, {"data": ["launch_ResolveURL", 2057, 153, 7.43801652892562, 4566.305298979092, 202, 33074, 2207.0, 8234.0, 30159.1, 32562.04, 1.2799914376848895, 1.4552394146357097, 1.1495778715646512], "isController": false}, {"data": ["launch_createEmptyCart", 1972, 139, 7.04868154158215, 4399.373732251523, 250, 33043, 2287.5, 7102.200000000006, 30165.0, 32689.97, 1.2318117251985452, 1.4325705229000172, 1.0164852615163777], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3118, 100.0, 8.468913816986719], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 36817, 3118, "500/Internal Server Error", 3118, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetCmsPage", 2008, 147, "500/Internal Server Error", 147, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["addSimpleProductToCart", 1171, 66, "500/Internal Server Error", 66, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 43, 7, "500/Internal Server Error", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 46, 2, "500/Internal Server Error", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 40, 11, "500/Internal Server Error", 11, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["checkUserIsAuthed", 1959, 138, "500/Internal Server Error", 138, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getAvailableStoresData", 1993, 159, "500/Internal Server Error", 159, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviewRatingsMetadata", 1133, 87, "500/Internal Server Error", 87, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 41, 7, "500/Internal Server Error", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1735, 341, "500/Internal Server Error", 341, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["createProductReview", 926, 48, "500/Internal Server Error", 48, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["updateItemQuantity", 77, 6, "500/Internal Server Error", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getStoreConfig", 2069, 137, "500/Internal Server Error", 137, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetCartDetails", 2102, 143, "500/Internal Server Error", 143, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 187, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ProductSearch", 1721, 334, "500/Internal Server Error", 334, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetAttributeProduct", 183, 8, "500/Internal Server Error", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getLandingPage", 2001, 127, "500/Internal Server Error", 127, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getWebTranslations", 1981, 267, "500/Internal Server Error", 267, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getMegaMenu", 2044, 278, "500/Internal Server Error", 278, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["CmsBlockList", 2019, 139, "500/Internal Server Error", 139, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getAllWebsites", 2031, 138, "500/Internal Server Error", 138, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AttributeProduct", 939, 61, "500/Internal Server Error", 61, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["amMostviewedGroups", 1116, 83, "500/Internal Server Error", 83, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviews", 1131, 82, "500/Internal Server Error", 82, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_ResolveURL", 2057, 153, "500/Internal Server Error", 153, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_createEmptyCart", 1972, 139, "500/Internal Server Error", 139, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
