/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.31306019659347, "KoPercent": 8.686939803406537};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21896070838636303, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.21788537549407114, 500, 1500, "GetCmsPage"], "isController": false}, {"data": [0.11989795918367346, 500, 1500, "addSimpleProductToCart"], "isController": false}, {"data": [0.0641025641025641, 500, 1500, "Catalog__ProductSearch(Sort descending)"], "isController": false}, {"data": [0.03488372093023256, 500, 1500, "Catalog__ProductSearch(Filtring)"], "isController": false}, {"data": [0.03773584905660377, 500, 1500, "Catalog__ProductSearch(RemoveFilter)"], "isController": false}, {"data": [0.1963377416073245, 500, 1500, "checkUserIsAuthed"], "isController": false}, {"data": [0.204, 500, 1500, "getAvailableStoresData"], "isController": false}, {"data": [0.19920494699646643, 500, 1500, "productReviewRatingsMetadata"], "isController": false}, {"data": [0.013513513513513514, 500, 1500, "Catalog__ProductSearch(SortBasedon value from drop down list)"], "isController": false}, {"data": [0.16455331412103746, 500, 1500, "Catalog__GetBreadcrumbs"], "isController": false}, {"data": [0.1318622174381055, 500, 1500, "createProductReview"], "isController": false}, {"data": [0.08666666666666667, 500, 1500, "updateItemQuantity"], "isController": false}, {"data": [0.16482194417709337, 500, 1500, "launch_getStoreConfig"], "isController": false}, {"data": [0.16539923954372623, 500, 1500, "GetCartDetails"], "isController": false}, {"data": [0.9997605363984674, 500, 1500, "JSR223 Sampler - Instead of Cache"], "isController": false}, {"data": [0.10106382978723404, 500, 1500, "Search_getAutocompleteResults(after adding space after the input)"], "isController": false}, {"data": [0.0933139534883721, 500, 1500, "ProductSearch"], "isController": false}, {"data": [0.14594594594594595, 500, 1500, "GetAttributeProduct"], "isController": false}, {"data": [0.1694831013916501, 500, 1500, "getLandingPage"], "isController": false}, {"data": [0.18967254408060452, 500, 1500, "getWebTranslations"], "isController": false}, {"data": [0.06648806624452021, 500, 1500, "getMegaMenu"], "isController": false}, {"data": [0.21639586410635156, 500, 1500, "CmsBlockList"], "isController": false}, {"data": [0.20720941638057871, 500, 1500, "launch_getAllWebsites"], "isController": false}, {"data": [0.13761955366631243, 500, 1500, "AttributeProduct"], "isController": false}, {"data": [0.182546749777382, 500, 1500, "amMostviewedGroups"], "isController": false}, {"data": [0.17108753315649866, 500, 1500, "productReviews"], "isController": false}, {"data": [0.21878025169409487, 500, 1500, "launch_ResolveURL"], "isController": false}, {"data": [0.1938259109311741, 500, 1500, "launch_createEmptyCart"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 36929, 3208, 8.686939803406537, 4244.927753256199, 0, 34376, 2369.0, 3263.0, 4983.950000000001, 32787.990000000005, 22.66841405811202, 43.7498944966377, 52.404121301819416], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetCmsPage", 2024, 142, 7.015810276679842, 4331.76581027669, 211, 33043, 2205.0, 7555.0, 30160.0, 32700.5, 1.2724789952948454, 2.105092407185734, 1.2289860608853536], "isController": false}, {"data": ["addSimpleProductToCart", 1176, 81, 6.887755102040816, 4727.974489795917, 283, 32992, 2766.5, 7352.5, 30165.0, 32656.82, 0.7728300299668788, 1.2984351074963199, 4.891052133784698], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 39, 8, 20.512820512820515, 5110.3589743589755, 263, 32567, 2562.0, 8402.0, 32514.0, 32567.0, 0.027997731465860713, 0.18404918986051386, 0.08579493142350517], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 43, 2, 4.651162790697675, 5714.511627906977, 343, 32816, 4771.0, 7931.600000000001, 26272.399999999943, 32816.0, 0.03841614693193463, 0.3770221313300653, 0.13404384080840082], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 53, 10, 18.867924528301888, 6592.000000000002, 241, 32844, 4222.0, 12434.200000000003, 31269.499999999993, 32844.0, 0.043449496518711564, 0.27365849423310407, 0.14303700426583876], "isController": false}, {"data": ["checkUserIsAuthed", 1966, 144, 7.3245167853509665, 4423.053916581888, 212, 33139, 2256.0, 7663.9, 30161.0, 32669.97, 1.2274013927197491, 1.2792225060293128, 1.064134737035807], "isController": false}, {"data": ["getAvailableStoresData", 2000, 146, 7.3, 4430.008999999985, 220, 32881, 2211.0, 7859.900000000012, 30161.95, 32455.510000000002, 1.2429462798617843, 1.4851059592282547, 1.177400284634698], "isController": false}, {"data": ["productReviewRatingsMetadata", 1132, 81, 7.15547703180212, 4419.9734982332175, 212, 33327, 2223.0, 7428.50000000001, 30161.7, 32775.73, 0.7325068688696228, 0.8465597949579327, 0.6570537980837051], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 37, 9, 24.324324324324323, 5038.270270270271, 744, 32786, 3615.0, 10481.80000000001, 15905.600000000028, 32786.0, 0.02515824194205309, 0.14838236541530478, 0.07763410617866023], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1735, 338, 19.481268011527376, 4305.511815561965, 201, 34376, 2207.0, 7310.800000000003, 30171.2, 32633.84, 1.0966825195759409, 1.1604597833562151, 1.0784999500646], "isController": false}, {"data": ["createProductReview", 929, 67, 7.21205597416577, 4585.133476856835, 240, 33115, 2604.0, 6703.0, 30176.0, 32711.4, 0.6101084929203772, 0.7596552880858092, 0.8437791683495547], "isController": false}, {"data": ["updateItemQuantity", 75, 7, 9.333333333333334, 5330.333333333334, 372, 32247, 2850.0, 17604.20000000012, 30161.0, 32247.0, 0.05324530110217773, 0.08618043168627869, 0.33574490176241945], "isController": false}, {"data": ["launch_getStoreConfig", 2078, 159, 7.651588065447545, 4826.744465832536, 394, 33360, 2426.0, 8552.500000000011, 30305.05, 32883.1, 1.2875515206491541, 3.7856890815181834, 9.569877562168664], "isController": false}, {"data": ["GetCartDetails", 2104, 147, 6.986692015209125, 4525.61739543726, 279, 33087, 2458.0, 7829.0, 30162.0, 32640.049999999996, 1.3159203217750415, 1.6040191497600509, 5.251843173835326], "isController": false}, {"data": ["JSR223 Sampler - Instead of Cache", 2088, 0, 0.0, 0.5833333333333329, 0, 689, 0.0, 1.0, 1.0, 1.0, 1.334957275613054, 0.0, 0.0], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 188, 11, 5.851063829787234, 4849.356382978722, 221, 32731, 2669.0, 9126.999999999998, 30156.1, 32544.989999999998, 0.12896613747104263, 0.22110184200344776, 0.1855328537376513], "isController": false}, {"data": ["ProductSearch", 1720, 330, 19.186046511627907, 4884.825581395358, 206, 33426, 2798.0, 7609.700000000003, 30157.0, 32552.649999999998, 1.1037988005814194, 7.331273228106118, 3.2133268413626137], "isController": false}, {"data": ["GetAttributeProduct", 185, 14, 7.5675675675675675, 4304.713513513514, 219, 32968, 2239.0, 6301.400000000003, 30213.8, 32873.4, 0.13055060600179946, 0.14130049463683997, 0.12088611223823721], "isController": false}, {"data": ["getLandingPage", 2012, 139, 6.9085487077534795, 4494.3543737574655, 294, 33132, 2405.0, 7850.700000000002, 30166.0, 32701.739999999998, 1.2612553879175246, 5.357823035275031, 13.39837510719417], "isController": false}, {"data": ["getWebTranslations", 1985, 264, 13.299748110831235, 4404.383375314846, 206, 33110, 2239.0, 7628.600000000001, 30162.0, 32705.28, 1.2339201861882994, 1.2351136523633457, 1.1484319491074748], "isController": false}, {"data": ["getMegaMenu", 2053, 285, 13.88212372138334, 5133.667803214805, 208, 32992, 2978.0, 8610.400000000009, 30158.0, 32677.38, 1.266050723431127, 3.8973285686072456, 1.7474117514698646], "isController": false}, {"data": ["CmsBlockList", 2031, 128, 6.3023141309699655, 4088.304775972438, 213, 33046, 2188.0, 6434.999999999998, 30157.0, 32605.920000000002, 1.2544222863467467, 4.098825110155694, 1.1155322018569898], "isController": false}, {"data": ["launch_getAllWebsites", 2039, 141, 6.9151544874938695, 4383.420794507114, 209, 33212, 2216.0, 7870.0, 30160.0, 32730.199999999997, 1.2732545360083127, 2.2244017793638475, 1.5181263291038263], "isController": false}, {"data": ["AttributeProduct", 941, 72, 7.651434643995749, 4362.27736450585, 227, 33057, 2535.0, 6742.4000000000015, 30155.9, 32781.020000000004, 0.6146189166770083, 0.6668464458975331, 0.573994457571047], "isController": false}, {"data": ["amMostviewedGroups", 1123, 92, 8.192341941228852, 4155.091718610869, 211, 33314, 2261.0, 6465.800000000001, 30160.0, 32577.56, 0.7244633133197386, 0.8136207499469393, 1.335393446921289], "isController": false}, {"data": ["productReviews", 1131, 93, 8.222811671087532, 4313.897435897432, 222, 33166, 2369.0, 6430.000000000002, 30160.0, 32721.280000000002, 0.7287582436346415, 0.8104287968642777, 0.8511492359636716], "isController": false}, {"data": ["launch_ResolveURL", 2066, 155, 7.50242013552759, 4446.159244917723, 200, 33024, 2202.0, 7979.5999999999985, 30161.0, 32606.0, 1.2739858985917092, 1.44799022712221, 1.143293564182127], "isController": false}, {"data": ["launch_createEmptyCart", 1976, 143, 7.2368421052631575, 4402.401315789476, 247, 33061, 2263.5, 7230.899999999999, 30166.0, 32578.120000000003, 1.235180645169356, 1.4352044054802389, 1.0192652784844782], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3208, 100.0, 8.686939803406537], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 36929, 3208, "500/Internal Server Error", 3208, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetCmsPage", 2024, 142, "500/Internal Server Error", 142, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["addSimpleProductToCart", 1176, 81, "500/Internal Server Error", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 39, 8, "500/Internal Server Error", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 43, 2, "500/Internal Server Error", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 53, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["checkUserIsAuthed", 1966, 144, "500/Internal Server Error", 144, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getAvailableStoresData", 2000, 146, "500/Internal Server Error", 146, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviewRatingsMetadata", 1132, 81, "500/Internal Server Error", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 37, 9, "500/Internal Server Error", 9, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1735, 338, "500/Internal Server Error", 338, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["createProductReview", 929, 67, "500/Internal Server Error", 67, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["updateItemQuantity", 75, 7, "500/Internal Server Error", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getStoreConfig", 2078, 159, "500/Internal Server Error", 159, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetCartDetails", 2104, 147, "500/Internal Server Error", 147, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 188, 11, "500/Internal Server Error", 11, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ProductSearch", 1720, 330, "500/Internal Server Error", 330, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetAttributeProduct", 185, 14, "500/Internal Server Error", 14, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getLandingPage", 2012, 139, "500/Internal Server Error", 139, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getWebTranslations", 1985, 264, "500/Internal Server Error", 264, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getMegaMenu", 2053, 285, "500/Internal Server Error", 285, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["CmsBlockList", 2031, 128, "500/Internal Server Error", 128, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getAllWebsites", 2039, 141, "500/Internal Server Error", 141, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AttributeProduct", 941, 72, "500/Internal Server Error", 72, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["amMostviewedGroups", 1123, 92, "500/Internal Server Error", 92, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviews", 1131, 93, "500/Internal Server Error", 93, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_ResolveURL", 2066, 155, "500/Internal Server Error", 155, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_createEmptyCart", 1976, 143, "500/Internal Server Error", 143, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
