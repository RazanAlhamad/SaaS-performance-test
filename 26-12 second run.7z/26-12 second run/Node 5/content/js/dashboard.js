/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.3602891592264, "KoPercent": 8.639710840773608};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21987699943355002, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.2031636183885319, 500, 1500, "GetCmsPage"], "isController": false}, {"data": [0.11049488054607509, 500, 1500, "addSimpleProductToCart"], "isController": false}, {"data": [0.038461538461538464, 500, 1500, "Catalog__ProductSearch(Sort descending)"], "isController": false}, {"data": [0.0, 500, 1500, "Catalog__ProductSearch(Filtring)"], "isController": false}, {"data": [0.03773584905660377, 500, 1500, "Catalog__ProductSearch(RemoveFilter)"], "isController": false}, {"data": [0.19944247339077548, 500, 1500, "checkUserIsAuthed"], "isController": false}, {"data": [0.20569146280579131, 500, 1500, "getAvailableStoresData"], "isController": false}, {"data": [0.19624125874125875, 500, 1500, "productReviewRatingsMetadata"], "isController": false}, {"data": [0.0, 500, 1500, "Catalog__ProductSearch(SortBasedon value from drop down list)"], "isController": false}, {"data": [0.1692351598173516, 500, 1500, "Catalog__GetBreadcrumbs"], "isController": false}, {"data": [0.1288936627282492, 500, 1500, "createProductReview"], "isController": false}, {"data": [0.10810810810810811, 500, 1500, "updateItemQuantity"], "isController": false}, {"data": [0.1770783277270543, 500, 1500, "launch_getStoreConfig"], "isController": false}, {"data": [0.16769157994323558, 500, 1500, "GetCartDetails"], "isController": false}, {"data": [0.9997621313035204, 500, 1500, "JSR223 Sampler - Instead of Cache"], "isController": false}, {"data": [0.0873015873015873, 500, 1500, "Search_getAutocompleteResults(after adding space after the input)"], "isController": false}, {"data": [0.09649626651349799, 500, 1500, "ProductSearch"], "isController": false}, {"data": [0.21122994652406418, 500, 1500, "GetAttributeProduct"], "isController": false}, {"data": [0.17304823470909994, 500, 1500, "getLandingPage"], "isController": false}, {"data": [0.18489713998996488, 500, 1500, "getWebTranslations"], "isController": false}, {"data": [0.06374212312166748, 500, 1500, "getMegaMenu"], "isController": false}, {"data": [0.2234513274336283, 500, 1500, "CmsBlockList"], "isController": false}, {"data": [0.2159257449926722, 500, 1500, "launch_getAllWebsites"], "isController": false}, {"data": [0.1365079365079365, 500, 1500, "AttributeProduct"], "isController": false}, {"data": [0.18121104185218165, 500, 1500, "amMostviewedGroups"], "isController": false}, {"data": [0.1710411198600175, 500, 1500, "productReviews"], "isController": false}, {"data": [0.21339113680154143, 500, 1500, "launch_ResolveURL"], "isController": false}, {"data": [0.19646464646464645, 500, 1500, "launch_createEmptyCart"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 37073, 3203, 8.639710840773608, 4218.939416826266, 0, 34740, 2369.0, 3259.0, 4955.950000000001, 32773.98, 22.75946111037783, 43.848368780522804, 52.5244036158493], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetCmsPage", 2023, 146, 7.217004448838359, 4396.444883835879, 210, 33728, 2210.0, 7537.6, 30158.0, 32594.28, 1.2616309526779257, 2.0843313254608726, 1.2185088009750666], "isController": false}, {"data": ["addSimpleProductToCart", 1172, 75, 6.399317406143345, 4546.612627986343, 291, 33099, 2745.5, 6766.000000000004, 30160.0, 32596.67, 0.7585853806616393, 1.2840899216559944, 4.800761910664273], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 39, 9, 23.076923076923077, 6129.128205128205, 219, 32942, 3681.0, 29997.0, 32659.0, 32942.0, 0.02938658886504473, 0.1797044067073759, 0.09005161655436972], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 41, 3, 7.317073170731708, 6965.804878048781, 1603, 32514, 4856.0, 12878.400000000001, 30161.6, 32514.0, 0.03454280907178417, 0.3303493449609203, 0.12052876641941879], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 53, 10, 18.867924528301888, 6922.056603773587, 473, 32613, 4171.0, 30173.8, 30362.2, 32613.0, 0.03606271373962176, 0.21688593937755757, 0.1187221587769841], "isController": false}, {"data": ["checkUserIsAuthed", 1973, 138, 6.9944247339077545, 4340.79219462749, 215, 33112, 2245.0, 7362.000000000003, 30164.0, 32631.62, 1.241962338263204, 1.296848738917233, 1.0766386177975784], "isController": false}, {"data": ["getAvailableStoresData", 2003, 142, 7.08936595107339, 4370.393409885157, 211, 33125, 2210.0, 6981.2000000000035, 30160.8, 32628.36, 1.2494721089504748, 1.4945056395840624, 1.1835819782050394], "isController": false}, {"data": ["productReviewRatingsMetadata", 1144, 54, 4.72027972027972, 3693.9947552447557, 209, 33259, 2226.0, 5863.5, 24013.25, 32516.199999999997, 0.7273277507961504, 0.850963832451406, 0.6524135934711526], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 39, 9, 23.076923076923077, 7129.282051282049, 228, 30371, 4156.0, 30160.0, 30182.0, 30371.0, 0.028285342535498106, 0.1613800046924658, 0.08728821576421919], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1752, 332, 18.949771689497716, 3953.808789954337, 199, 32987, 2196.0, 6532.2000000000035, 30157.35, 32531.4, 1.1123964906176467, 1.1829263696461156, 1.0939500523975572], "isController": false}, {"data": ["createProductReview", 931, 62, 6.659505907626208, 4455.698174006443, 233, 33017, 2604.0, 6694.800000000001, 30160.8, 32671.12, 0.6136348207111969, 0.7667764046288893, 0.8486989549423308], "isController": false}, {"data": ["updateItemQuantity", 74, 8, 10.81081081081081, 5864.297297297297, 263, 32495, 2860.5, 30165.0, 30346.5, 32495.0, 0.051722824373751926, 0.08513283657579526, 0.32619931316108236], "isController": false}, {"data": ["launch_getStoreConfig", 2081, 146, 7.015857760691975, 4485.480538202784, 385, 33197, 2384.0, 7632.199999999997, 30301.0, 32792.08, 1.2974745695607852, 3.8355446063386713, 9.643631786061656], "isController": false}, {"data": ["GetCartDetails", 2114, 139, 6.575212866603595, 4450.148060548726, 291, 32972, 2462.5, 7612.5, 30161.0, 32700.8, 1.325751755805808, 1.6177466790357509, 5.290983774905664], "isController": false}, {"data": ["JSR223 Sampler - Instead of Cache", 2102, 0, 0.0, 0.5176022835394875, 0, 707, 0.0, 1.0, 1.0, 1.0, 1.3398408891138245, 0.0, 0.0], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 189, 17, 8.994708994708995, 5525.698412698413, 301, 32831, 2769.0, 9625.0, 30300.0, 32750.899999999998, 0.12879642804572886, 0.21905295270922265, 0.18531922390611627], "isController": false}, {"data": ["ProductSearch", 1741, 340, 19.529006318207927, 5076.87191269385, 207, 33065, 2833.0, 8289.4, 30161.9, 32690.559999999998, 1.1063120791359455, 7.289582890837627, 3.2206455960073637], "isController": false}, {"data": ["GetAttributeProduct", 187, 7, 3.7433155080213902, 3212.8930481283423, 227, 32659, 2242.0, 4405.600000000002, 9670.0, 32028.040000000005, 0.12621958833515012, 0.13849232874296763, 0.11684711420341602], "isController": false}, {"data": ["getLandingPage", 2011, 147, 7.3097961213326705, 4688.4211834908065, 298, 33152, 2446.0, 8169.2, 30173.4, 32730.079999999994, 1.2465999003215993, 5.276235361478327, 13.242689175486674], "isController": false}, {"data": ["getWebTranslations", 1993, 288, 14.45057701956849, 4460.25539387857, 205, 33091, 2233.0, 7688.200000000001, 30172.0, 32777.12, 1.2399283043964884, 1.2380035536730931, 1.1543236793410399], "isController": false}, {"data": ["getMegaMenu", 2063, 283, 13.717886572952011, 5284.085312651485, 206, 33142, 3020.0, 9448.600000000002, 30161.0, 32683.079999999998, 1.276586001860115, 3.9301137135379376, 1.7618950139508636], "isController": false}, {"data": ["CmsBlockList", 2034, 140, 6.882989183874139, 4255.040314650936, 213, 34647, 2191.0, 7074.0, 30161.0, 32585.55, 1.2597079261268627, 4.102473343846382, 1.1201540688132485], "isController": false}, {"data": ["launch_getAllWebsites", 2047, 158, 7.718612603810454, 4596.248168050814, 211, 32990, 2210.0, 8320.600000000004, 30162.6, 32586.52, 1.2630937219243945, 2.194401542052629, 1.5060117034781046], "isController": false}, {"data": ["AttributeProduct", 945, 75, 7.936507936507937, 4287.0793650793685, 229, 33058, 2535.0, 6902.199999999997, 30153.0, 32645.999999999996, 0.6073042311432036, 0.6591235340752298, 0.5671618281415783], "isController": false}, {"data": ["amMostviewedGroups", 1123, 86, 7.658058771148709, 4078.480854853069, 214, 32995, 2250.0, 6620.800000000001, 30157.0, 32664.4, 0.7363977885771129, 0.827983882363896, 1.3573562432089763], "isController": false}, {"data": ["productReviews", 1143, 87, 7.611548556430447, 4128.515310586174, 217, 33131, 2360.0, 6526.000000000001, 30155.0, 32521.6, 0.7276973186613934, 0.8117495322969005, 0.8498823410764444], "isController": false}, {"data": ["launch_ResolveURL", 2076, 147, 7.08092485549133, 4402.795761079007, 198, 34740, 2194.5, 8047.9, 30156.15, 32647.36, 1.2932822831540638, 1.472837699264212, 1.161203260242534], "isController": false}, {"data": ["launch_createEmptyCart", 1980, 155, 7.828282828282828, 4527.024242424242, 248, 33220, 2259.5, 7592.300000000012, 30176.0, 32629.38, 1.2442852429655464, 1.4416161961320324, 1.0267783499080925], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3203, 100.0, 8.639710840773608], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 37073, 3203, "500/Internal Server Error", 3203, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetCmsPage", 2023, 146, "500/Internal Server Error", 146, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["addSimpleProductToCart", 1172, 75, "500/Internal Server Error", 75, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 39, 9, "500/Internal Server Error", 9, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 41, 3, "500/Internal Server Error", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 53, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["checkUserIsAuthed", 1973, 138, "500/Internal Server Error", 138, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getAvailableStoresData", 2003, 142, "500/Internal Server Error", 142, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviewRatingsMetadata", 1144, 54, "500/Internal Server Error", 54, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 39, 9, "500/Internal Server Error", 9, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1752, 332, "500/Internal Server Error", 332, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["createProductReview", 931, 62, "500/Internal Server Error", 62, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["updateItemQuantity", 74, 8, "500/Internal Server Error", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getStoreConfig", 2081, 146, "500/Internal Server Error", 146, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetCartDetails", 2114, 139, "500/Internal Server Error", 139, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 189, 17, "500/Internal Server Error", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ProductSearch", 1741, 340, "500/Internal Server Error", 340, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetAttributeProduct", 187, 7, "500/Internal Server Error", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getLandingPage", 2011, 147, "500/Internal Server Error", 147, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getWebTranslations", 1993, 288, "500/Internal Server Error", 288, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getMegaMenu", 2063, 283, "500/Internal Server Error", 283, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["CmsBlockList", 2034, 140, "500/Internal Server Error", 140, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getAllWebsites", 2047, 158, "500/Internal Server Error", 158, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AttributeProduct", 945, 75, "500/Internal Server Error", 75, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["amMostviewedGroups", 1123, 86, "500/Internal Server Error", 86, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviews", 1143, 87, "500/Internal Server Error", 87, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_ResolveURL", 2076, 147, "500/Internal Server Error", 147, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_createEmptyCart", 1980, 155, "500/Internal Server Error", 155, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
