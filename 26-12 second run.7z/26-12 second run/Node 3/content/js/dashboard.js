/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.45229345311012, "KoPercent": 8.547706546889888};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21991288961480876, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.22056631892697467, 500, 1500, "GetCmsPage"], "isController": false}, {"data": [0.11063094209161625, 500, 1500, "addSimpleProductToCart"], "isController": false}, {"data": [0.13829787234042554, 500, 1500, "Catalog__ProductSearch(Sort descending)"], "isController": false}, {"data": [0.03260869565217391, 500, 1500, "Catalog__ProductSearch(Filtring)"], "isController": false}, {"data": [0.041666666666666664, 500, 1500, "Catalog__ProductSearch(RemoveFilter)"], "isController": false}, {"data": [0.19723360655737704, 500, 1500, "checkUserIsAuthed"], "isController": false}, {"data": [0.20586760280842528, 500, 1500, "getAvailableStoresData"], "isController": false}, {"data": [0.20124113475177305, 500, 1500, "productReviewRatingsMetadata"], "isController": false}, {"data": [0.07317073170731707, 500, 1500, "Catalog__ProductSearch(SortBasedon value from drop down list)"], "isController": false}, {"data": [0.17042824074074073, 500, 1500, "Catalog__GetBreadcrumbs"], "isController": false}, {"data": [0.1320043103448276, 500, 1500, "createProductReview"], "isController": false}, {"data": [0.07352941176470588, 500, 1500, "updateItemQuantity"], "isController": false}, {"data": [0.1761006289308176, 500, 1500, "launch_getStoreConfig"], "isController": false}, {"data": [0.1633045148895293, 500, 1500, "GetCartDetails"], "isController": false}, {"data": [0.9997581035316885, 500, 1500, "JSR223 Sampler - Instead of Cache"], "isController": false}, {"data": [0.12834224598930483, 500, 1500, "Search_getAutocompleteResults(after adding space after the input)"], "isController": false}, {"data": [0.09532163742690059, 500, 1500, "ProductSearch"], "isController": false}, {"data": [0.1864864864864865, 500, 1500, "GetAttributeProduct"], "isController": false}, {"data": [0.17581047381546136, 500, 1500, "getLandingPage"], "isController": false}, {"data": [0.20196671709531014, 500, 1500, "getWebTranslations"], "isController": false}, {"data": [0.06188845401174168, 500, 1500, "getMegaMenu"], "isController": false}, {"data": [0.20652173913043478, 500, 1500, "CmsBlockList"], "isController": false}, {"data": [0.2182890855457227, 500, 1500, "launch_getAllWebsites"], "isController": false}, {"data": [0.13738019169329074, 500, 1500, "AttributeProduct"], "isController": false}, {"data": [0.17381590705987487, 500, 1500, "amMostviewedGroups"], "isController": false}, {"data": [0.160603371783496, 500, 1500, "productReviews"], "isController": false}, {"data": [0.2203018500486855, 500, 1500, "launch_ResolveURL"], "isController": false}, {"data": [0.18223350253807108, 500, 1500, "launch_createEmptyCart"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 36735, 3140, 8.547706546889888, 4280.878154348732, 0, 33305, 2367.0, 3281.9000000000015, 5185.950000000001, 32765.99, 22.542535343332602, 43.399224437794324, 52.05463767426972], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetCmsPage", 2013, 136, 6.756085444610035, 4284.4197714853435, 210, 33175, 2199.0, 7403.200000000005, 30160.0, 32663.879999999997, 1.2459798117846292, 2.064823692580014, 1.2033926111865219], "isController": false}, {"data": ["addSimpleProductToCart", 1157, 74, 6.395851339671564, 4638.645635263618, 292, 33012, 2773.0, 7280.200000000004, 30166.0, 32603.0, 0.7648722028782201, 1.2910510923227854, 4.840591679386992], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 47, 5, 10.638297872340425, 4943.872340425533, 277, 30159, 3893.0, 9114.800000000001, 22168.999999999887, 30159.0, 0.031763023515450343, 0.23437505279757898, 0.09734487627795484], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 46, 5, 10.869565217391305, 7815.543478260867, 443, 30684, 4881.5, 30155.6, 30171.15, 30684.0, 0.033534907286916646, 0.30880677468916423, 0.11701193724233709], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 36, 9, 25.0, 5426.666666666667, 750, 30497, 4022.5, 10642.500000000002, 30205.45, 30497.0, 0.028443006141319078, 0.15374608340793036, 0.09363029617662791], "isController": false}, {"data": ["checkUserIsAuthed", 1952, 134, 6.864754098360656, 4332.021004098361, 219, 33101, 2257.0, 6938.900000000001, 30160.0, 32698.46, 1.2264064406443158, 1.2809706452126168, 1.0631991502329041], "isController": false}, {"data": ["getAvailableStoresData", 1994, 153, 7.673019057171515, 4534.169007021059, 219, 32999, 2208.5, 8060.5, 30163.0, 32714.05, 1.2389548788042408, 1.4774377468278965, 1.1736193676172983], "isController": false}, {"data": ["productReviewRatingsMetadata", 1128, 74, 6.560283687943262, 4177.281914893617, 204, 33305, 2250.5, 6967.700000000008, 30157.0, 32599.530000000002, 0.7300777131480654, 0.8462944156902633, 0.6548768113192466], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 41, 7, 17.073170731707318, 5556.512195121951, 232, 30296, 4037.0, 6657.800000000005, 30160.0, 30296.0, 0.03111732445654731, 0.18658091234856866, 0.09602834195321168], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1728, 303, 17.53472222222222, 4027.1215277777765, 196, 32949, 2167.0, 6526.200000000003, 30156.0, 32586.440000000002, 1.0844802590702842, 1.1531851165204374, 1.0665405450407621], "isController": false}, {"data": ["createProductReview", 928, 67, 7.219827586206897, 4647.003232758616, 230, 32887, 2592.0, 7944.600000000002, 30160.65, 32507.600000000002, 0.6186233630312544, 0.7704096129937571, 0.8555455805593608], "isController": false}, {"data": ["updateItemQuantity", 68, 8, 11.764705882352942, 6285.073529411764, 725, 33163, 2957.0, 30157.1, 30536.499999999996, 33163.0, 0.05257042310686562, 0.08589804198366761, 0.33153068643829975], "isController": false}, {"data": ["launch_getStoreConfig", 2067, 145, 7.014997581035317, 4523.211417513305, 386, 33255, 2399.0, 7529.4000000000015, 30302.0, 32796.88, 1.2739709310280642, 3.7663899960076694, 9.468938238334568], "isController": false}, {"data": ["GetCartDetails", 2082, 154, 7.39673390970221, 4631.537463976938, 266, 33111, 2463.0, 7939.200000000003, 30166.85, 32744.17, 1.3001456887556133, 1.5780499026529966, 5.188776986648528], "isController": false}, {"data": ["JSR223 Sampler - Instead of Cache", 2067, 0, 0.0, 0.6560232220609588, 0, 732, 0.0, 1.0, 1.0, 1.0, 1.318958157057479, 0.0, 0.0], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 187, 11, 5.882352941176471, 4633.197860962567, 208, 32748, 2770.0, 8166.6, 30152.8, 32698.72, 0.1275939265290972, 0.22389106613084042, 0.18360950467287168], "isController": false}, {"data": ["ProductSearch", 1710, 329, 19.239766081871345, 5516.673684210523, 213, 33068, 2956.0, 9680.200000000008, 30175.45, 32660.469999999998, 1.0793676042015803, 7.058308653056535, 3.1422434744417114], "isController": false}, {"data": ["GetAttributeProduct", 185, 17, 9.18918918918919, 4916.718918918919, 225, 32797, 2225.0, 14095.600000000053, 32460.899999999998, 32790.12, 0.12954556117386484, 0.13858174701292444, 0.11993153538974657], "isController": false}, {"data": ["getLandingPage", 2005, 158, 7.8802992518703245, 4754.395511221944, 292, 33253, 2439.0, 8392.000000000004, 30168.7, 32699.16, 1.2455636501662097, 5.243900499460152, 13.231681041511749], "isController": false}, {"data": ["getWebTranslations", 1983, 260, 13.111447302067575, 4378.345940494196, 205, 33017, 2224.0, 7531.800000000025, 30166.0, 32673.48, 1.2420181699178563, 1.2419698493121298, 1.1557695586153658], "isController": false}, {"data": ["getMegaMenu", 2044, 253, 12.377690802348337, 4982.9584148727945, 211, 32970, 2984.5, 8372.0, 30158.0, 32456.899999999998, 1.264701223616996, 3.93925884598643, 1.7454863132752791], "isController": false}, {"data": ["CmsBlockList", 2024, 162, 8.003952569169961, 4641.0810276679895, 215, 33085, 2228.0, 8329.0, 30168.0, 32529.5, 1.2573482500557545, 4.062047480426926, 1.1180446324461697], "isController": false}, {"data": ["launch_getAllWebsites", 2034, 130, 6.391347099311701, 4179.455260570304, 216, 33057, 2195.0, 7207.5, 30157.0, 32562.9, 1.2533467253697959, 2.1979824666636882, 1.4943102298880677], "isController": false}, {"data": ["AttributeProduct", 939, 77, 8.20021299254526, 4532.361022364219, 234, 32965, 2552.0, 8157.0, 30160.0, 32672.8, 0.6099628565749319, 0.6596512412321899, 0.5696592380628515], "isController": false}, {"data": ["amMostviewedGroups", 1119, 87, 7.774798927613941, 4258.631814119749, 234, 32831, 2261.0, 7425.0, 30163.0, 32540.8, 0.7230382337965775, 0.8122752671251509, 1.332752168064713], "isController": false}, {"data": ["productReviews", 1127, 88, 7.808340727595386, 4281.534161490682, 219, 33131, 2365.0, 6568.4000000000015, 30161.6, 32730.88, 0.7235495143486866, 0.8053253908339053, 0.8450568892410691], "isController": false}, {"data": ["launch_ResolveURL", 2054, 141, 6.8646543330087635, 4275.664070107109, 197, 33028, 2181.5, 7595.0, 30160.0, 32582.8, 1.2626433382962061, 1.4397373124399875, 1.1337517792421188], "isController": false}, {"data": ["launch_createEmptyCart", 1970, 153, 7.766497461928934, 4678.739086294413, 250, 33088, 2272.5, 8167.700000000006, 30163.45, 32597.45, 1.2267088770756756, 1.4214925729237953, 1.012274415164986], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3140, 100.0, 8.547706546889888], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 36735, 3140, "500/Internal Server Error", 3140, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetCmsPage", 2013, 136, "500/Internal Server Error", 136, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["addSimpleProductToCart", 1157, 74, "500/Internal Server Error", 74, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 47, 5, "500/Internal Server Error", 5, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 46, 5, "500/Internal Server Error", 5, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 36, 9, "500/Internal Server Error", 9, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["checkUserIsAuthed", 1952, 134, "500/Internal Server Error", 134, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getAvailableStoresData", 1994, 153, "500/Internal Server Error", 153, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviewRatingsMetadata", 1128, 74, "500/Internal Server Error", 74, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 41, 7, "500/Internal Server Error", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1728, 303, "500/Internal Server Error", 303, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["createProductReview", 928, 67, "500/Internal Server Error", 67, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["updateItemQuantity", 68, 8, "500/Internal Server Error", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getStoreConfig", 2067, 145, "500/Internal Server Error", 145, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetCartDetails", 2082, 154, "500/Internal Server Error", 154, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 187, 11, "500/Internal Server Error", 11, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ProductSearch", 1710, 329, "500/Internal Server Error", 329, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetAttributeProduct", 185, 17, "500/Internal Server Error", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getLandingPage", 2005, 158, "500/Internal Server Error", 158, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getWebTranslations", 1983, 260, "500/Internal Server Error", 260, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getMegaMenu", 2044, 253, "500/Internal Server Error", 253, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["CmsBlockList", 2024, 162, "500/Internal Server Error", 162, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getAllWebsites", 2034, 130, "500/Internal Server Error", 130, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AttributeProduct", 939, 77, "500/Internal Server Error", 77, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["amMostviewedGroups", 1119, 87, "500/Internal Server Error", 87, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviews", 1127, 88, "500/Internal Server Error", 88, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_ResolveURL", 2054, 141, "500/Internal Server Error", 141, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_createEmptyCart", 1970, 153, "500/Internal Server Error", 153, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
