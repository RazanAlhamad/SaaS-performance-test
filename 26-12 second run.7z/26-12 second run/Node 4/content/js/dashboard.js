/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.40978659193792, "KoPercent": 8.590213408062082};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.22262341021771934, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.21899606299212598, 500, 1500, "GetCmsPage"], "isController": false}, {"data": [0.11072961373390558, 500, 1500, "addSimpleProductToCart"], "isController": false}, {"data": [0.06521739130434782, 500, 1500, "Catalog__ProductSearch(Sort descending)"], "isController": false}, {"data": [0.06896551724137931, 500, 1500, "Catalog__ProductSearch(Filtring)"], "isController": false}, {"data": [0.013157894736842105, 500, 1500, "Catalog__ProductSearch(RemoveFilter)"], "isController": false}, {"data": [0.20161697827185449, 500, 1500, "checkUserIsAuthed"], "isController": false}, {"data": [0.20876930742401595, 500, 1500, "getAvailableStoresData"], "isController": false}, {"data": [0.22081881533101044, 500, 1500, "productReviewRatingsMetadata"], "isController": false}, {"data": [0.015625, 500, 1500, "Catalog__ProductSearch(SortBasedon value from drop down list)"], "isController": false}, {"data": [0.16248574686431014, 500, 1500, "Catalog__GetBreadcrumbs"], "isController": false}, {"data": [0.14224137931034483, 500, 1500, "createProductReview"], "isController": false}, {"data": [0.1323529411764706, 500, 1500, "updateItemQuantity"], "isController": false}, {"data": [0.1754680748919827, 500, 1500, "launch_getStoreConfig"], "isController": false}, {"data": [0.1697530864197531, 500, 1500, "GetCartDetails"], "isController": false}, {"data": [0.9997615641392466, 500, 1500, "JSR223 Sampler - Instead of Cache"], "isController": false}, {"data": [0.1111111111111111, 500, 1500, "Search_getAutocompleteResults(after adding space after the input)"], "isController": false}, {"data": [0.0924441900400687, 500, 1500, "ProductSearch"], "isController": false}, {"data": [0.17473118279569894, 500, 1500, "GetAttributeProduct"], "isController": false}, {"data": [0.17798710956866634, 500, 1500, "getLandingPage"], "isController": false}, {"data": [0.18734367183591796, 500, 1500, "getWebTranslations"], "isController": false}, {"data": [0.06401551891367604, 500, 1500, "getMegaMenu"], "isController": false}, {"data": [0.20622854340362923, 500, 1500, "CmsBlockList"], "isController": false}, {"data": [0.22035139092240116, 500, 1500, "launch_getAllWebsites"], "isController": false}, {"data": [0.1456361724500526, 500, 1500, "AttributeProduct"], "isController": false}, {"data": [0.1804078014184397, 500, 1500, "amMostviewedGroups"], "isController": false}, {"data": [0.15851528384279476, 500, 1500, "productReviews"], "isController": false}, {"data": [0.23502415458937198, 500, 1500, "launch_ResolveURL"], "isController": false}, {"data": [0.20135746606334842, 500, 1500, "launch_createEmptyCart"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 37112, 3188, 8.590213408062082, 4214.0916145720885, 0, 33606, 2362.5, 3232.0, 4993.800000000003, 32759.0, 22.7827042490431, 44.172840462712294, 52.5483272107348], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetCmsPage", 2032, 154, 7.578740157480315, 4494.304133858266, 208, 33118, 2197.0, 7975.300000000002, 30164.35, 32716.08, 1.257517566257932, 2.072263446913203, 1.214496121545385], "isController": false}, {"data": ["addSimpleProductToCart", 1165, 79, 6.781115879828326, 4779.332188841199, 273, 33223, 2767.0, 7525.0, 30164.7, 32791.78, 0.7589423275490854, 1.2826218218475718, 4.803355635610942], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 46, 4, 8.695652173913043, 3438.3478260869574, 327, 10144, 2944.5, 7066.300000000001, 8523.149999999998, 10144.0, 0.03726672850783209, 0.27723775058836875, 0.11420768074363326], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 58, 5, 8.620689655172415, 7139.01724137931, 223, 33042, 5061.0, 15313.800000000023, 32234.35, 33042.0, 0.039630913205566914, 0.3742336083895227, 0.13828247351903378], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 38, 10, 26.31578947368421, 5920.315789473685, 374, 32538, 3962.0, 10110.90000000003, 30297.899999999994, 32538.0, 0.02895418989986422, 0.1664173911722485, 0.09531547875753], "isController": false}, {"data": ["checkUserIsAuthed", 1979, 127, 6.417382516422435, 4160.87620010107, 225, 33326, 2258.0, 6770.0, 30159.0, 32492.8, 1.24498530112099, 1.3020477008191487, 1.079535551163926], "isController": false}, {"data": ["getAvailableStoresData", 2007, 150, 7.473841554559043, 4405.837568510217, 216, 33181, 2202.0, 7775.000000000002, 30161.6, 32635.6, 1.2602311365627148, 1.5042839205150182, 1.1937736352205404], "isController": false}, {"data": ["productReviewRatingsMetadata", 1148, 88, 7.665505226480836, 4409.803135888491, 215, 33232, 2219.5, 7805.400000000027, 30169.1, 32760.65, 0.7328822830176875, 0.8450310676971281, 0.6574052930794974], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 32, 10, 31.25, 7331.375000000001, 451, 32013, 3503.0, 30259.8, 31604.8, 32013.0, 0.026582820021847756, 0.18127393492193372, 0.0820312986745972], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1754, 354, 20.182440136830103, 4109.872291904219, 201, 33020, 2188.5, 6462.0, 30158.0, 32641.0, 1.1201376351557177, 1.1869431641908474, 1.1015802665787076], "isController": false}, {"data": ["createProductReview", 928, 53, 5.711206896551724, 4219.596982758622, 225, 33106, 2569.0, 6706.200000000001, 30154.55, 32767.940000000002, 0.6211209224716597, 0.779960137699095, 0.8591245050024329], "isController": false}, {"data": ["updateItemQuantity", 68, 3, 4.411764705882353, 3970.985294117648, 409, 32681, 2792.5, 4954.800000000004, 21255.549999999945, 32681.0, 0.051093897810701616, 0.0861593158451945, 0.3222528647334138], "isController": false}, {"data": ["launch_getStoreConfig", 2083, 142, 6.817090734517523, 4505.096015362465, 379, 33268, 2415.0, 7914.400000000013, 30302.0, 32728.319999999996, 1.2831190079019925, 3.799738090185464, 9.536932391740299], "isController": false}, {"data": ["GetCartDetails", 2106, 146, 6.932573599240266, 4535.792022792033, 264, 33425, 2449.5, 7372.799999999999, 30163.0, 32657.93, 1.3176574228347653, 1.6036990350161517, 5.258954012246519], "isController": false}, {"data": ["JSR223 Sampler - Instead of Cache", 2097, 0, 0.0, 0.5302813543156886, 0, 659, 0.0, 1.0, 1.0, 1.0, 1.3420138655567053, 0.0, 0.0], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 189, 11, 5.8201058201058204, 4581.0952380952385, 222, 32719, 2706.0, 6536.0, 30159.0, 32594.8, 0.13026487190620928, 0.22733756306473957, 0.18738834978013494], "isController": false}, {"data": ["ProductSearch", 1747, 360, 20.606754436176303, 5138.527761877497, 205, 33163, 2573.0, 8874.400000000001, 30163.0, 32688.36, 1.1027223418363514, 7.396734137793583, 3.210208793721489], "isController": false}, {"data": ["GetAttributeProduct", 186, 16, 8.602150537634408, 4850.983870967744, 213, 32749, 2257.0, 8827.00000000002, 30332.9, 32718.55, 0.1300724769436045, 0.1394401483473103, 0.12041729444702413], "isController": false}, {"data": ["getLandingPage", 2017, 132, 6.544372830937035, 4413.184928111057, 269, 33156, 2409.0, 6991.600000000006, 30163.0, 32559.46, 1.2566602369524151, 5.355933450860971, 13.349560603094114], "isController": false}, {"data": ["getWebTranslations", 1999, 253, 12.65632816408204, 4260.5702851425685, 210, 33108, 2225.0, 7414.0, 30163.0, 32662.0, 1.2590428754800929, 1.2629036985329223, 1.1718148457074133], "isController": false}, {"data": ["getMegaMenu", 2062, 294, 14.25800193986421, 5469.981571290006, 208, 33120, 3037.0, 10303.0, 30167.85, 32589.769999999997, 1.280246761043991, 3.9194751484980697, 1.7671944004570892], "isController": false}, {"data": ["CmsBlockList", 2039, 136, 6.669936243256498, 4378.129475232957, 213, 33557, 2226.0, 8211.0, 30158.0, 32618.0, 1.2635761622235966, 4.125243901881669, 1.12352793222175], "isController": false}, {"data": ["launch_getAllWebsites", 2049, 140, 6.832601268911664, 4275.14299658371, 208, 33218, 2191.0, 7515.0, 30157.5, 32663.0, 1.267594132319753, 2.2159734549920564, 1.511337836687292], "isController": false}, {"data": ["AttributeProduct", 951, 68, 7.150368033648791, 4194.208201892742, 227, 33606, 2529.0, 6523.400000000009, 30160.0, 32504.32, 0.6205684171785867, 0.6741221899458129, 0.5795123727459532], "isController": false}, {"data": ["amMostviewedGroups", 1128, 84, 7.446808510638298, 4178.578014184398, 218, 32890, 2282.5, 7040.1, 30164.55, 32613.65, 0.7370939938601638, 0.8288701957791567, 1.3586022622349108], "isController": false}, {"data": ["productReviews", 1145, 98, 8.558951965065502, 4608.164192139746, 218, 33210, 2376.0, 7946.600000000006, 30164.7, 32662.98, 0.7410096758390075, 0.8218326164307408, 0.8654028325984717], "isController": false}, {"data": ["launch_ResolveURL", 2070, 141, 6.811594202898551, 4236.293236714975, 201, 32992, 2185.5, 7038.4000000000015, 30158.0, 32598.09, 1.2827901615571957, 1.4632642274675118, 1.1520056958671847], "isController": false}, {"data": ["launch_createEmptyCart", 1989, 130, 6.5359477124183005, 4179.420814479642, 245, 32880, 2265.0, 6717.0, 30156.0, 32566.0, 1.2471587791763987, 1.454001492130798, 1.0291495785195868], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 3188, 100.0, 8.590213408062082], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 37112, 3188, "500/Internal Server Error", 3188, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetCmsPage", 2032, 154, "500/Internal Server Error", 154, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["addSimpleProductToCart", 1165, 79, "500/Internal Server Error", 79, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Sort descending)", 46, 4, "500/Internal Server Error", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(Filtring)", 58, 5, "500/Internal Server Error", 5, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(RemoveFilter)", 38, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["checkUserIsAuthed", 1979, 127, "500/Internal Server Error", 127, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getAvailableStoresData", 2007, 150, "500/Internal Server Error", 150, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviewRatingsMetadata", 1148, 88, "500/Internal Server Error", 88, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__ProductSearch(SortBasedon value from drop down list)", 32, 10, "500/Internal Server Error", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Catalog__GetBreadcrumbs", 1754, 354, "500/Internal Server Error", 354, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["createProductReview", 928, 53, "500/Internal Server Error", 53, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["updateItemQuantity", 68, 3, "500/Internal Server Error", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getStoreConfig", 2083, 142, "500/Internal Server Error", 142, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetCartDetails", 2106, 146, "500/Internal Server Error", 146, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Search_getAutocompleteResults(after adding space after the input)", 189, 11, "500/Internal Server Error", 11, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ProductSearch", 1747, 360, "500/Internal Server Error", 360, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetAttributeProduct", 186, 16, "500/Internal Server Error", 16, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getLandingPage", 2017, 132, "500/Internal Server Error", 132, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getWebTranslations", 1999, 253, "500/Internal Server Error", 253, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["getMegaMenu", 2062, 294, "500/Internal Server Error", 294, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["CmsBlockList", 2039, 136, "500/Internal Server Error", 136, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_getAllWebsites", 2049, 140, "500/Internal Server Error", 140, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AttributeProduct", 951, 68, "500/Internal Server Error", 68, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["amMostviewedGroups", 1128, 84, "500/Internal Server Error", 84, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["productReviews", 1145, 98, "500/Internal Server Error", 98, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_ResolveURL", 2070, 141, "500/Internal Server Error", 141, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["launch_createEmptyCart", 1989, 130, "500/Internal Server Error", 130, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
